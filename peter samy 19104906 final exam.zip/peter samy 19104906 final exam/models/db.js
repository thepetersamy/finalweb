const mysql = require('mysql');

// Create a MySQL connection pool
const pool = mysql.createPool({
    host: '127.0.0.1',
    user: 'root',
    password: 'password@PASSWORD123',
    database: 'final2',
});

// Use the pool to perform database queries
const query = (sql, params, callback) => {
    pool.getConnection((err, connection) => {
        if (err) {
            console.error('Database connection error:', err);
            callback(err, null);
            return;
        }

        connection.query(sql, params, (error, results) => {
            connection.release(); // Release the connection back to the pool

            if (error) {
                console.error('Database query error:', error);
                callback(error, null);
                return;
            }

            callback(null, results);
        });
    });
};

module.exports = { query };
