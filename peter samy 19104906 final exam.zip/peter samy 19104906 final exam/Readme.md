# Web Final Exam Peter Samy 19104906

## Description
Briefly describe your project here.

## Installation
1. Clone this repository: `git clone https://github.com/your-username/your-repo.git`
2. Run: `npm init -y`
3. Install dependencies: `npm install express express-session body-parser ejs mysql`

## Configuration
1. Create a MySQL database and update the connection details in `models/db.js`.
2. Run the `db.sql` to set up the database schema.

## Usage
1. Start the application: `node app.js`
2. Open your browser and navigate to `http://localhost:3000`

### Default Login Credentials
- Username: JohnDoe
- Password: password123
