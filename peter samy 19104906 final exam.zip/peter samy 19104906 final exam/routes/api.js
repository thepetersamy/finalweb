const express = require('express');
const router = express.Router();
const db = require('../models/db');

router.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Check username and password in the database
    const sql = 'SELECT * FROM Employees WHERE Username = ? AND Password = ?';
    db.query(sql, [username, password], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.json({ success: false, message: 'Error querying the database.' });
        }

        if (results.length > 0) {
            // Successful login
            const user = results[0];

            // Log the login
            const logSql = 'INSERT INTO Log (Username, LoginDate) VALUES (?, NOW())';
            db.query(logSql, [user.Username], (logErr, logResults) => {
                if (logErr) {
                    console.error('Login log error:', logErr);
                    return res.json({ success: false, message: 'Error logging the login.' });
                }

                // Set the session variable
                req.session.loggedin = true;

                // Return success to the frontend
                res.json({ success: true, message: 'Login successful.' });
            });
        } else {
            // Failed login
            res.json({ success: false, message: 'Wrong credentials.' });
        }
    });
});



router.post('/logout', (req, res) => {
    // Clear the session
    req.session.destroy(err => {
        if (err) {
            console.error('Logout error:', err);
            return res.json({ success: false, message: 'Logout error' });
        }
        res.json({ success: true });
    });
});

router.post('/adddepartment', (req, res) => {
    const { departmentName } = req.body;

    // Placeholder logic for add department API
    // Insert department into the database
    db.query('INSERT INTO Departments (Name) VALUES (?)', [departmentName], (err, result) => {
        if (err) {
            res.json({ success: false, message: 'Error happened. Please try again later' });
        } else {
            res.json({ success: true, message: 'Department added successfully' });
        }
    });
});

router.post('/adduser', (req, res) => {
    const { username, password, departmentId } = req.body;

    // Placeholder logic for add user API
    // Insert user into the database
    db.query('INSERT INTO Employees (Username, Password, DepartmentID) VALUES (?, ?, ?)', [username, password, departmentId], (err, result) => {
        if (err) {
            res.json({ success: false, message: 'Error happened. Please try again later' });
        } else {
            res.json({ success: true, message: 'User added successfully' });
        }
    });
});

router.post('/deleteuser', (req, res) => {
    const userId = req.body.userId;

    // Placeholder logic for delete user API
    // Delete user from the database
    db.query('DELETE FROM Employees WHERE ID = ?', [userId], (err, result) => {
        if (err) {
            res.json({ success: false, message: 'Error happened. Please try again later' });
        } else {
            res.json({ success: true, message: 'User deleted successfully' });
        }
    });
});

// "/api/getdepartments" route
router.get('/getdepartments', (req, res) => {
    const sql = 'SELECT * FROM Departments';
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.json({ success: false, message: 'Error querying the database.' });
        }

        res.json({ success: true, departments: results });
    });
});

// "/api/getusers" route
router.get('/getusers', (req, res) => {
    const sql = 'SELECT * FROM Employees';
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.json({ success: false, message: 'Error querying the database.' });
        }

        res.json({ success: true, users: results });
    });
});

// router.get('/getloginhistory', (req, res) => {
//     const sql = 'SELECT * FROM Log';
//     db.query(sql, (err, results) => {
//         if (err) {
//             console.error('Database error:', err);
//             return res.json({ success: false, message: 'Error querying the database.' });
//         }

//         res.json({ success: true, loginHistory: results });
//         console.log(loginHistory);
//     });
// });

router.get('/getloginhistory', (req, res) => {
    const sql = 'SELECT * FROM Log';
    console.log('getloginhistory API called');
    
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.json({ success: false, message: 'Error querying the database.' });
        }

        console.log(results);  // Log the results, not loginHistory
        res.json({ success: true, loginHistory: results });
    });
});

module.exports = router;
