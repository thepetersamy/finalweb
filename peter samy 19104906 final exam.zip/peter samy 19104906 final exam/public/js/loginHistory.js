function logout() {
    // Make an AJAX request to logout
    $.ajax({
        type: 'POST',
        url: '/api/logout',
        success: function (response) {
            console.log('Logout response:', response);
            if (response.success) {
                // Redirect to the index page after successful logout
                window.location.href = '/';
            } else {
                alert('Logout error');
            }
        },
        error: function (error) {
            console.error('Ajax request failed', error);
            alert('Error occurred. Please try again later.');
        }
    });
}    
$(document).ready(function () {
    updateLoginHistoryTable();
});

// Function for updating the login history table
function updateLoginHistoryTable() {
    // Make an AJAX request to fetch the login history data from the server
    $.ajax({
        type: 'GET',
        url: '/api/getloginhistory',
        success: function (data) {
            // Update the login history table HTML here
            const loginHistoryTableBody = $('#loginHistoryTableBody');
            loginHistoryTableBody.empty(); // Clear existing data

            data.loginHistory.forEach(log => {
                const row = `<tr>
                                <td>${log.Username}</td>
                                <td>${log.LoginDate}</td>
                            </tr>`;
                loginHistoryTableBody.append(row);
            });
        },
        error: function (error) {
            console.error('Ajax request failed', error);
        }
    });
}