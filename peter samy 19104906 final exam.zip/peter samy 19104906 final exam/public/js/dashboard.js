function logout() {
    $.ajax({
      type: "POST",
      url: "/api/logout",
      success: function (response) {
        console.log("Logout response:", response);
        if (response.success) {
          // Redirect to the index page after successful logout
          window.location.href = "/";
        } else {
          alert("Logout error");
        }
      },
      error: function (error) {
        console.error("Ajax request failed", error);
        alert("Error occurred. Please try again later.");
      },
    });
  }

  $(document).ready(function () {
    updateDepartmentTable();
    updateUserTable();
  });


  function submitAddDepartmentForm() {
    const departmentName = $(
      '#addDepartmentForm input[name="departmentName"]'
    ).val();

    $.ajax({
      type: "POST",
      url: "/api/adddepartment",
      data: { departmentName: departmentName },
      success: function (response) {
        console.log("Add Department response:", response);
        if (response.success) {
          // Update the department table using jQuery
          updateDepartmentTable();
          console.log("Department added successfully");
        } else {
          alert("Error happened. Please try again later.");
        }
      },
      error: function (error) {
        console.error("Ajax request failed", error);
        alert("Error occurred. Please try again later.");
      },
    });
  }
  function submitAddUserForm() {
    const username = $('#addUserForm input[name="username"]').val();
    const password = $('#addUserForm input[name="password"]').val();
    const departmentId = $('#addUserForm input[name="departmentId"]').val();

    $.ajax({
      type: "POST",
      url: "/api/adduser",
      data: { username, password, departmentId },
      success: function (response) {
        console.log("Add User response:", response);
        if (response.success) {
          // Update the user table using jQuery
          updateUserTable();
          console.log("User added successfully");
        } else {
          alert("Error happened. Please try again later.");
        }
      },
      error: function (error) {
        console.error("Ajax request failed", error);
        alert("Error occurred. Please try again later.");
      },
    });
  }
  function updateDepartmentTable() {
    // Make an AJAX request to fetch the updated department data from the server
    $.ajax({
      type: "GET",
      url: "/api/getdepartments",
      success: function (data) {
        // Update the department table HTML here
        const departmentTableBody = $("#departmentTableBody");
        departmentTableBody.empty(); // Clear existing data

        data.departments.forEach((department) => {
          const row = `<tr>
                                    <td>${department.ID}</td>
                                    <td>${department.Name}</td>
                                </tr>`;
          departmentTableBody.append(row);
        });
      },
      error: function (error) {
        console.error("Ajax request failed", error);
      },
    });
  }

  // New function for updating the user table
  function updateUserTable() {
    // Make an AJAX request to fetch the updated user data from the server
    $.ajax({
      type: "GET",
      url: "/api/getusers",
      success: function (data) {
        // Update the user table HTML here
        const userTableBody = $("#userTableBody");
        userTableBody.empty(); // Clear existing data

        data.users.forEach((user) => {
          const row = `<tr>
                                    <td>${user.Username}</td>
                                    <td>${user.Password}</td>
                                    <td>${user.DepartmentID}</td>
                                    <td><button class="btn btn-danger" onclick="deleteUser(${user.ID})">Delete</button></td>
                                </tr>`;
          userTableBody.append(row);
        });
      },
      error: function (error) {
        console.error("Ajax request failed", error);
      },
    });
  }

  function deleteUser(userId) {
    // Make an AJAX request to delete the user by userId
    $.ajax({
      type: "POST",
      url: "/api/deleteuser",
      data: { userId: userId },
      success: function (response) {
        console.log("Delete User response:", response);
        if (response.success) {
          // Update the user table after successful deletion
          updateUserTable();
          console.log("User deleted successfully");
        } else {
          alert("Error happened. Please try again later.");
        }
      },
      error: function (error) {
        console.error("Ajax request failed", error);
        alert("Error occurred. Please try again later.");
      },
    });
  }