-- Create the Departments table
CREATE TABLE Departments (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Name NVARCHAR(255) NOT NULL
);

-- Create the Employees table with a foreign key constraint
CREATE TABLE Employees (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Username NVARCHAR(255) NOT NULL,
    Password NVARCHAR(255) NOT NULL,
    DepartmentID INT,
    FOREIGN KEY (DepartmentID) REFERENCES Departments(ID)
);

-- Create the Log table
CREATE TABLE Log (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Username NVARCHAR(255) NOT NULL,
    LoginDate DATETIME NOT NULL
);


-- Insert into the Departments table
INSERT INTO Departments (Name) VALUES
('Engineering'),
('Marketing');

-- Insert into the Employees table
INSERT INTO Employees (Username, Password, DepartmentID) VALUES
('JohnDoe', 'password123', 1),
('JaneSmith', 'securepass', 2); 
